using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Avalonia.Input;
using DynamicData;

namespace Names;

internal static class PieChartTask
{
    public static PieChartData GetTopFivePopularNameInYear(NameData[] names, string year)
    {
        var titleOfEachPie = new string[5];
        var amountOfSmth = new double[5];
        var nameToAmount = new Dictionary<string, int>();
        foreach(var name in names)
        {
            if (name.BirthDate.Year == double.Parse(year))
            {
                var strName = name.Name.ToString();
                if (!nameToAmount.ContainsKey(strName))
                {
                    nameToAmount.Add(strName, 1);
                }
                else
                {
                    nameToAmount[strName]++;
                }              
            }
        }
        nameToAmount = nameToAmount.OrderBy(pair => pair.Value).ToDictionary(pair => pair.Key, pair => pair.Value);
        for(var i = 0; i < titleOfEachPie.Length; i++)
        {
            titleOfEachPie[i] = nameToAmount.ElementAt(nameToAmount.Count - i - 1).Key;
            amountOfSmth[i] = nameToAmount.ElementAt(nameToAmount.Count - i - 1).Value;
        }

        return new PieChartData(
            $"Топ 5 по популярности имен в {year} году ", 
            titleOfEachPie, 
            amountOfSmth);
    } 
}